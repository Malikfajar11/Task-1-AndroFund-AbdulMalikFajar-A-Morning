package com.example.il_project_1

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var tv : TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tv = findViewById(R.id.textView2)

        val Username = intent.getParcelableExtra<UserLogin>("UserLogin")?.Username
        val Password = intent.getParcelableExtra<UserLogin>("UserLogin")?.Password
        tv.text ="Username : $Username dan Password : $Password"

        val btnMainActivity: Button = findViewById(R.id.btn_Implicit)
        btnMainActivity.setOnClickListener(this)
    }
    override fun onClick(v: View) {
        when (v.id) {
            R.id.btn_Implicit -> {
                val message = "Welcome to Rbzl Project"
                val intent = Intent()
                intent.action = Intent.ACTION_SEND
                intent.putExtra(Intent.EXTRA_TEXT, message)
                intent.type = "text/plain"
                startActivity(intent)
            }

        }
    }
    }

